package com.soulland.mod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

@Mod(modid = SoulLand.MODID, name = "Soul Land", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class SoulLand {
    public static final String MODID = "soulland";

    @SidedProxy(clientSide = "com.soulland.mod.ClientProxy", serverSide = "com.soulland.mod.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NetworkHandler.init();
        proxy.preInit();
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent e) {
        java.util.Set<Biome> cold = BiomeDictionary.getBiomes(BiomeDictionary.Type.COLD);
        java.util.Set<Biome> forest = BiomeDictionary.getBiomes(BiomeDictionary.Type.FOREST);
        if (!cold.isEmpty()) EntityRegistry.addSpawn(EntitySoulBear.class, 4, 1, 1, EnumCreatureType.MONSTER, cold.toArray(new Biome[0]));
        if (!forest.isEmpty()) EntityRegistry.addSpawn(EntitySoulWolf.class, 5, 1, 2, EnumCreatureType.MONSTER, forest.toArray(new Biome[0]));
    }
}
