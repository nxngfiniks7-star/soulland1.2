package com.soulland.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** สั่งให้ฝั่งไคลเอนต์เรนเดอร์เอฟเฟกต์สกิล (เถาวัลย์ กรง หอก กระจก พายุ ฯลฯ) */
public class PacketFx implements IMessage {
    public int type, dur, ent = -1, pal;
    public double x, y, z, x2, y2, z2;

    public PacketFx() {}

    public PacketFx(int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent) {
        this.type = type; this.x = x; this.y = y; this.z = z; this.x2 = x2; this.y2 = y2; this.z2 = z2;
        this.dur = dur; this.ent = ent;
    }

    public PacketFx(int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent, int pal) {
        this(type, x, y, z, x2, y2, z2, dur, ent);
        this.pal = pal;
    }

    @Override public void fromBytes(ByteBuf b) {
        type = b.readByte(); dur = b.readShort(); ent = b.readInt(); pal = b.readByte();
        x = b.readDouble(); y = b.readDouble(); z = b.readDouble();
        x2 = b.readDouble(); y2 = b.readDouble(); z2 = b.readDouble();
    }

    @Override public void toBytes(ByteBuf b) {
        b.writeByte(type); b.writeShort(dur); b.writeInt(ent); b.writeByte(pal);
        b.writeDouble(x); b.writeDouble(y); b.writeDouble(z);
        b.writeDouble(x2); b.writeDouble(y2); b.writeDouble(z2);
    }

    public static class Handler implements IMessageHandler<PacketFx, IMessage> {
        @Override
        public IMessage onMessage(PacketFx m, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() -> ClientFx.add(m));
            return null;
        }
    }
}
