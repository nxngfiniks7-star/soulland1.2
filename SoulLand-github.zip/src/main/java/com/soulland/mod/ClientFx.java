package com.soulland.mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ClientFx {
    public static class Fx {
        public int type, dur, age, ent, pal;
        public double x, y, z, x2, y2, z2;
    }

    public static final List<Fx> LIST = new ArrayList<>();

    public static void add(PacketFx m) {
        if (LIST.size() > 80) LIST.remove(0);
        Fx f = new Fx();
        f.type = m.type; f.pal = m.pal; f.dur = Math.max(1, m.dur); f.ent = m.ent;
        f.x = m.x; f.y = m.y; f.z = m.z; f.x2 = m.x2; f.y2 = m.y2; f.z2 = m.z2;
        LIST.add(f);
    }

    public static void tick() {
        Iterator<Fx> it = LIST.iterator();
        while (it.hasNext()) {
            Fx f = it.next();
            f.age++;
            if (f.age >= f.dur) it.remove();
        }
    }
}
